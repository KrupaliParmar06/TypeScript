var fnm:string = "Krupali"; 
var lnm:string = "Parmar"; 
var fullnm=fnm+" "+lnm;

var numInt:number = 50;
var numFloat:number = 42.50
var sum = numInt + numFloat;

console.log("Firstname: "+fnm); 
console.log("Lastname: "+lnm); 
console.log("Fullname: "+fullnm); 

console.log("Integer Number: "+numInt); 
console.log("Float Number: "+numFloat);
console.log("Sum: "+sum);