// Number.
// String.
// Boolean.
// Void.
// null.
// Undefined.
// Nan.
var FirstCLS = /** @class */ (function () {
    function FirstCLS() {
    }
    FirstCLS.prototype.demoFun = function () {
        console.log("Hello Guys..!!");
    };
    return FirstCLS;
}());
var obj = new FirstCLS();
obj.demoFun();
